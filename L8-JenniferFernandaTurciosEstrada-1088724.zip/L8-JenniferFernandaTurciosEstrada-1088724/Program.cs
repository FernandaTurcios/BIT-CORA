﻿using System.Data;
using Microsoft.VisualBasic;

class Program
{
    static void Main(string[] args)
    {
        int opcion = 0;
        string entrada;
        do
        {
            Console.WriteLine("Menu");
            Console.WriteLine("1) sumatoria");
            Console.WriteLine("2) factorial");
            Console.WriteLine("3) tablas");
            Console.WriteLine("4) salida");
            Console.WriteLine("Ingrese un número 1-4");
            entrada = Console.ReadLine();
            try
            {
                opcion = int.Parse(entrada);
            }
            catch (FormatException)
            {
                Console.WriteLine("error, ingrese un número");
            }

            switch (opcion)
            {
                case 1:
                    Console.WriteLine("Ingrese un número positivo:");
                    string entradaNumero = Console.ReadLine();
                    int n = 0;
                    try
                    {
                        n = int.Parse(entradaNumero);
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("error, ingrese un número");
                    }

                    int i = 1;
                    int sumatoria = 0;
                    while(i <= n)
                    {
                        sumatoria += i;
                        i++;
                    }

                    Console.WriteLine($"Sumatoria: {sumatoria}");

                    break;
                case 2:

                    Console.WriteLine("Ingrese un número positivo:");
                    string entradaNumerof = Console.ReadLine();
                    int nf = 0;
                    try
                    {
                        nf = int.Parse(entradaNumerof);
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("error, ingrese un número");
                    }

                    int j = 1;
                    int factorial = 1;
                    while(j <= nf)
                    {
                        factorial *= j;
                        j++;
                    }

                    Console.WriteLine($"Factorial: {factorial}");


                    break;

                case 3:
                    string titulo = "\t";
                    for (int iTitulo = 1; iTitulo <= 10; iTitulo++)
                    {
                        titulo += iTitulo + "\t";
                    }
                    Console.WriteLine(titulo);

                    string fila = "";
                    for (int iFila = 1; iFila <= 10; iFila++)
                    {
                        fila = iFila + "\t";
                        for (int multiplo = 1; multiplo <= 10; multiplo++)
                        {
                            fila += iFila * multiplo + "\t";
                        }
                        Console.WriteLine(fila);
                    }
                    break;

                default:
                    Console.WriteLine("error, ingrese un número del 1 al 4");
                    break;
            }
        }
        while (opcion != 4);
    }
}
